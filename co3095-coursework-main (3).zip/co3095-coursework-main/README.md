To-do List Application:

Instructions to run:

1. Open the project in an IDE of your choice (Recommended: IntelliJ IDEA, Eclipse(to see test coverage))
2. Open 'co3095 coursework' -> src -> taskManager 
3. Run Main.java

If it does not compile due to JUnit not being found, add JUnit4 and JUnit 5.8.1 to the build path.
