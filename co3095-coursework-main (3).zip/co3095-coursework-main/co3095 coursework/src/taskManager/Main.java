package taskManager;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

	
	public static void main(String[] args) {

		String choice = null;
		Scanner choiceInput = new Scanner(System.in);
		String username=null;
		do{
			
			while (username==null) {
				try {
				Scanner logInChoice = new Scanner(System.in);
				
				System.out.println("Would you like to log in (1) or create an account(2)?");
				int userChoice = logInChoice.nextInt();
				if (userChoice == 1){
					System.out.println("LOG IN");
					Scanner input = new Scanner(System.in);
					System.out.println("Enter username:");
					String usernameinp = input.nextLine();
					System.out.println("Enter password:");
					String passwordinp = input.nextLine();
					System.out.println(" ");
					username = ManageAccount.confirmDetails(usernameinp,passwordinp);
					
				} else if (userChoice == 2) {
					System.out.println("CREATE ACCOUNT");
					Scanner input = new Scanner(System.in);
					System.out.println("Enter username:");
					String usernameinp = input.nextLine();
					System.out.println("Enter password:");
					String passwordinp = input.nextLine();

					
					username = ManageAccount.createAccValidator(usernameinp, passwordinp);
				}
				else {
					System.out.println("Failed to detect a valid number input - please enter 1 or 2");

					
				}
			}
				catch (Exception e) {
					System.out.println("Failed to detect a valid input - please enter 1 or 2");
				}

			}




			
			ArrayList<Task> upcomingTasks = TodoList.getUpcomingTasks();
			TodoList.showUpcomingTasks(upcomingTasks);


			System.out.println("Hello, "+username+". Please choose an option: \n");
			System.out.println("1. View tasks");
			System.out.println("2. Add a new task");
			System.out.println("3. Edit an existing task");
			System.out.println("4. Delete an existing task");
			System.out.println("5. Log out");
			System.out.println("6. Close App");
			
			choice = choiceInput.nextLine();

			
			try {
				switch (choice) {
				case "1":
					TodoList.listTasks(username);
					break;
				case "2":
					TodoList.addTask(username);
					break;
				case "3":
					Scanner editChoice = new Scanner(System.in);   
                    System.out.println("Enter Task Id to Edit");
                    int idToEdit = editChoice.nextInt();
                    TodoList.editTask(idToEdit, username);
					break;
				case "4":
					Scanner delChoice = new Scanner(System.in);				
					System.out.println("Enter Task Id to Delete");
					int idToDelete = delChoice.nextInt();
					TodoList.deleteTask(idToDelete);
					break;
				case "5":
					username = ManageAccount.logout();
					break;
				case "6":
					System.out.println("Exiting to-do app...");
					System.exit(0);
					break;
				default:
					System.out.println("Failed to detect a valid input - please enter a number between 1 and 6");
			}
		}
			catch (Exception e) {
				System.out.println("Failed to detect a valid input - please enter a number");
			}
		
	}


		while (Integer.valueOf(choice) > 0);
	}


}