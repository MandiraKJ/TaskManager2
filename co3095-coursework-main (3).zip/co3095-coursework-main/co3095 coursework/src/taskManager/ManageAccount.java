package taskManager;

import taskManager.Account;

import java.util.ArrayList;
import java.util.Scanner;

public class ManageAccount{

	public static ArrayList<Account> accounts = new ArrayList<Account> ();
	public String username;

	public static String createAccValidator (String usernameinp, String passwordinp) {
		Account account = new Account();

		for (int i = 0; i < accounts.size(); i++) {
			if (accounts.get(i).getUsername().equals(usernameinp)) {
				System.out.println("Username is already taken, Please try again.");
				return null;
			}
		}
		if (usernameinp.length() < 3) {
			System.out.println("Minimum username length is 3 characters, Please try again.");
			return null;
		} else if (usernameinp.length() > 15) {
			System.out.println("Maximum username length is 15 characters, Please try again.");
			return null;
		} else if (passwordinp.length() < 5) {
			System.out.println("Minimum password length is 5 characters. Please try again");
			return null;
		} else if (passwordinp.length() > 20) {
			System.out.println("Maximum password length is 20 characters. Please try again");
			return null;
		}  else if (usernameinp.contains(" ")) {
			System.out.println("Username cannot contain any spaces. Please try again");
			return null;
		}  else if (passwordinp.contains(" ")) {
			System.out.println("Password cannot contain any spaces. Please try again");
			return null;
		}

		account.setUsername(usernameinp);
		account.setPassword(passwordinp);
		accounts.add(account);
		System.out.println("Account created Successfully");


		return confirmDetails(usernameinp,passwordinp);
	}

	public static String confirmDetails(String usernameinp, String passwordinp) {
		boolean accFound= false;
		for (int i=0; i< accounts.size(); i++) {
			if (accounts.get(i).getUsername().equals(usernameinp) && accounts.get(i).getPassword().equals(passwordinp)) {
				System.out.println(usernameinp + " is logged in");
				accFound=true;
				String username=usernameinp;
				return username;
			}
		}
		if (accFound==false) {
			System.out.println("Incorrect details entered, Try again.");
		}
		return null;
	}


	public static String logout() {
		System.out.println("User has been logged out");
		return null;

	}

}

