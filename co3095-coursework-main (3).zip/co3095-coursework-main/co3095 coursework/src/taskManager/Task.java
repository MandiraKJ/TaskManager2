package taskManager;

import java.time.LocalDate;

public class Task {	
	private long id;
	private String taskname;
	private String taskdesc;
	private String owner;
	


	private LocalDate taskdue;
	private String priority;
	private String category;
	
	
	public LocalDate getTaskdue() {
		return taskdue;
	}
	public void setTaskdue(LocalDate taskdue) {
		this.taskdue = taskdue;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getTaskname() {
		return taskname;
	}
	public void setTaskname(String taskname) {
		this.taskname = taskname;
	}
	public String getTaskdesc() {
		return taskdesc;
	}
	public void setTaskdesc(String taskdesc) {
		this.taskdesc = taskdesc;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return
				"Task " + id +
				": taskname='" + taskname + '\'' +
				", taskdesc='" + taskdesc + '\'' +
				", taskdue=" + taskdue +
				", priority='" + priority + '\'' +
				", category='" + category + '\'' +
				", owner='" + owner + '\'' +
				'}' + '\n';
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}


}
