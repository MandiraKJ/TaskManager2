package taskManager;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoField;
import java.util.*;

public class TodoList {

    static ArrayList<Task> todolist = new ArrayList<Task>();

    public static void SetTodoList(ArrayList<Task> list)
    {
        todolist = list;
    }

    public static ArrayList<Task> addTask(String username){

        Scanner scanner = new Scanner(System.in);
        Task task = new Task();

        while (task.getTaskname()==null) {
            System.out.println("Enter task name (Less than 30 characters inc. spaces)");
            String nameinput = (scanner.nextLine());
            if (nameinput.length() < 30) {
                task.setTaskname(nameinput);
            }else {
                System.out.println("Try again");
            }
        }

        while (task.getTaskdesc()==null){
            System.out.println("Enter task description");
            String descinput = scanner.nextLine();
            if (descinput.length()>0) {
                task.setTaskdesc(descinput);
            } else {
                System.out.println("Try again");
            }
        }


        System.out.println("Enter task due date (format yyyy-mm-dd)");
        task.setTaskdue(LocalDate.parse(scanner.nextLine()));


        while (task.getPriority()==null){
//            Scanner priorityInput = new Scanner(System.in);
            System.out.println("Enter task priority (0. None, 1. Low, 2. Medium, 3. High)");
            String priority = scanner.nextLine();
            if ( priority.equalsIgnoreCase("none") ||  priority.equals("0") ){
                task.setPriority("None");
                break;
            } else if (priority.equalsIgnoreCase("low") || priority.equals("1")) {
                task.setPriority("Low");
                break;
            } else if (priority.equalsIgnoreCase("medium") || priority.equals("2")) {
                task.setPriority("Medium");
                break;
            } else if (priority.equalsIgnoreCase("high") || priority.equals("3")) {
                task.setPriority("High");
                break;
            }else {
                System.out.println("Please enter a valid priority level (0. None, 1. Low, 2. Medium, 3. High)");
            }

        }

        System.out.println("Enter task category");
        task.setCategory(scanner.nextLine());
        
        task.setOwner(username);

        todolist.add(task);
        return todolist;
    }

    public static ArrayList<Task> listTasks(String username){
        int id = 0;
        ArrayList<Task> taskList = new ArrayList<>();
    	for (int i=0; i< todolist.size(); i++){
            todolist.get(i).setId(id);
            Task temp = todolist.get(i);
            taskList.add(temp);
            id += 1;
        }
        System.out.println(taskList);
        return taskList;
    }
    
    public static void editTask(int id, String username) {
        // deletes the task to be edited then calls the add task function
        TodoList.deleteTask(id);
        TodoList.addTask(username);
    }

    public static void deleteTask(int id) {
    	try {
        	Task t =todolist.get(id);
        	todolist.remove(t);
    	}
        // catches all input ID's that fail to correspond to an ID already in the todo list
    	catch (Exception e){
    		System.out.println("Failed to detect a task with that task ID");
    	}
    	
    }


    //this method will return all tasks due today
    public static ArrayList<Task> getUpcomingTasks()
    {
        //int id = 0;
        ArrayList<Task> todolistToday = new ArrayList<Task>();
        Calendar now = Calendar.getInstance();
        Date today = now.getTime();
        //Date input = new Date();
        LocalDate localdatetoday = today.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

        for (int i=0; i< todolist.size(); i++)
        {
            //todolist.get(i).setId(id);
            LocalDate taskDate = todolist.get(i).getTaskdue();

            int taskDay = taskDate.get(ChronoField.DAY_OF_MONTH);
            int localdatetodayDay = localdatetoday.get(ChronoField.DAY_OF_MONTH);

            if(taskDate.getYear() == localdatetoday.getYear() && taskDate.getMonthValue() == localdatetoday.getMonthValue() && taskDay == localdatetodayDay) {
                todolistToday.add(todolist.get(i));
            }

            //id += 1;

        }
        return todolistToday;


    }

    public static void showUpcomingTasks(ArrayList<Task> tasks)
    {
        int id = 0;
        System.out.println("");
        System.out.println("YOUR TASKS FOR TODAY ARE: ");
        for (int i=0; i< tasks.size(); i++)
        {
            tasks.get(i).setId(id);
            id += 1;
            System.out.println(tasks.get(i).toString());
        }
        System.out.println("============================");
    }

}





