package testing.Blackbox;

import org.junit.Test;
import taskManager.Task;
import taskManager.TodoList;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

//Run each test individually
public class BlackboxtestAddTask {

    @Test
    public void testTaskNameisValid() {
        TodoList list2 = new TodoList();
        String input = 
                 "grr" + System.getProperty("line.separator")
                + "Desc" + System.getProperty("line.separator")
                + "2022-12-07" + System.getProperty("line.separator")
                + "1" + System.getProperty("line.separator")
                + "das" + System.getProperty("line.separator");
        ByteArrayInputStream taskName = new ByteArrayInputStream(input.getBytes());
        System.setIn(taskName);
        ArrayList<Task> response = list2.addTask("mandira");
        assertTrue(response.get(0).getTaskname().length() > 0);
    }
}
