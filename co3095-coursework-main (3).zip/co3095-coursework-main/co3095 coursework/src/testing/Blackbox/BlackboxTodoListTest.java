package testing.Blackbox;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import taskManager.Task;
import taskManager.TodoList;

import java.io.ByteArrayInputStream;
import java.time.LocalDate;
import java.util.ArrayList;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class BlackboxTodoListTest {

    @Test
    public void testGetUpComingTasks() {
        ArrayList<Task> todoTaskList = new ArrayList<Task>();
        Task task1 = new Task();
        task1.setId(1);
        task1.setTaskname("bob");
        task1.setTaskdue(LocalDate.parse("2022-12-06"));
        todoTaskList.add(task1);

        Task task2 = new Task();
        task2.setId(2);
        task2.setTaskname("bobby");
        //Needs to get todays date automatically so upcoming task will display
        task2.setTaskdue(LocalDate.parse("2022-12-08"));
        todoTaskList.add(task2);
        TodoList.SetTodoList(todoTaskList);
        //Now call the method to test
        System.out.println("test case check upcomingTasks");
        ArrayList<Task> upComingTasks = TodoList.getUpcomingTasks();
        assertEquals(1, upComingTasks.size());
    }

    
    @Test
    public void testAddTaskMethod() {
        TodoList list = new TodoList();
        String input = "Name" + System.getProperty("line.separator")
                + "Desc" + System.getProperty("line.separator")
                + "2022-12-07" + System.getProperty("line.separator")
                + "1" + System.getProperty("line.separator")
                + "das" + System.getProperty("line.separator");
        ByteArrayInputStream taskName = new ByteArrayInputStream(input.getBytes());
        System.setIn(taskName);
        ArrayList<Task> response = list.addTask("muazmmil");
        assertTrue(response.size() > 0);
    }

    
    @Test
    public void testTaskNameisInvalid() {
        TodoList list1 = new TodoList();
        String input = "mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm" + System.getProperty("line.separator")
                + "mmmmmmmmmmmmmmmmmmmmmmmmm" + System.getProperty("line.separator")
                + "Desc" + System.getProperty("line.separator")
                + "2022-12-07" + System.getProperty("line.separator")
                + "1" + System.getProperty("line.separator")
                + "das" + System.getProperty("line.separator");
        ByteArrayInputStream taskName = new ByteArrayInputStream(input.getBytes());
        System.setIn(taskName);
        ArrayList<Task> response = list1.addTask("mandira");
        Assertions.assertTrue(response.get(0).getTaskname().length() < 30);
    }
}
