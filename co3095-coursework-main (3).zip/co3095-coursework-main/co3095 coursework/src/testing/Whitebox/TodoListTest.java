package testing.Whitebox;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import taskManager.Task;
import taskManager.TodoList;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.ArrayList;

public class TodoListTest {

    ArrayList<Task> todolist = new ArrayList<Task>();

    @Before
    public void setUp() throws Exception {
    	
        Task task = new Task();
        
        task.setId(0);
        task.setTaskname("Buy Groceries");
        task.setTaskdesc("Buy Groceries from Sainsbury's");
        task.setOwner("Michael");
        task.setTaskdue(LocalDate.of(2022, 12, 07));
        task.setPriority("High");
        task.setCategory("Personal");
        
        todolist.add(task);
    }

    
    @Test
    public final void testListTasksSize() {
    	
        assertEquals("List size should be 1", 1, todolist.size());
    }

    
    @Test
    public void testDeleteTaskMethod() {
        TodoList list = new TodoList();
        
        String input = "Name" + System.getProperty("line.separator")
                + "Desc" + System.getProperty("line.separator")
                + "2022-12-07" + System.getProperty("line.separator")
                + "1" + System.getProperty("line.separator")
                + "das" + System.getProperty("line.separator");
        ByteArrayInputStream taskName = new ByteArrayInputStream(input.getBytes());
        System.setIn(taskName);


        ArrayList<Task> response = list.addTask("muazmmil");
        list.deleteTask(0);
        ArrayList<Task> response1 = list.listTasks("muazmmil");
        
        assertEquals("List should be null", 0, response1.size());
    }


    @Test
    public void testEditTaskMethod() {
        TodoList list = new TodoList();
        String input = "Name" + System.getProperty("line.separator")
                + "Desc" + System.getProperty("line.separator")
                + "2022-12-07" + System.getProperty("line.separator")
                + "1" + System.getProperty("line.separator")
                + "das" + System.getProperty("line.separator");
        ByteArrayInputStream taskName = new ByteArrayInputStream(input.getBytes());
        
        System.setIn(taskName);

        ArrayList<Task> response = list.addTask("muazmmil");
        String input2 = "Name2" + System.getProperty("line.separator")
                + "Desc2" + System.getProperty("line.separator")
                + "2022-12-08" + System.getProperty("line.separator")
                + "2" + System.getProperty("line.separator")
                + "da" + System.getProperty("line.separator");

        ByteArrayInputStream taskName2 = new ByteArrayInputStream(input.getBytes());
        System.setIn(taskName2);

        list.editTask(1, "muazmmil");
        ArrayList<Task> response1 = list.listTasks("muazmmil");
        
        assertEquals("List size should be 2", 2, response.size());
    }

    @After
    public void tearDown() throws Exception {
        todolist = null;
    }
}
