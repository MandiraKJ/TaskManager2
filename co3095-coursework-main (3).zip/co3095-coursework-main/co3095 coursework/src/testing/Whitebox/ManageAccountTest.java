package testing.Whitebox;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import taskManager.Account;
import taskManager.ManageAccount;

public class ManageAccountTest {


	Account account =new Account();
	static ArrayList<Account> accounts = new ArrayList<Account> ();

	//creating valid account tests
	@Test
	public final void testCreatingValidAccount() {
		assertEquals("Creating valid account",ManageAccount.createAccValidator("user1", "password"),"user1");
	}
	
	@Test
	public final void testCreatingValidAccount2() {
		assertEquals("Creating valid account",ManageAccount.createAccValidator("viran", "rashford"),"viran");
	}
	
	@Test
	public final void testCreatingValidAccount3() {
		assertEquals("Creating valid account",ManageAccount.createAccValidator("marcus", "rashford"),"marcus");
	}
	
	
	//creating duplicate username for account test
	@Test
	public final void testCreatingDuplicateAccount() {
		assertEquals("Creating valid account",ManageAccount.createAccValidator("jeff", "password"),"jeff");
		assertEquals("Creating valid but duplicate account",ManageAccount.createAccValidator("jeff", "password2"),null);
	}
	
	
	//Testing for invalid username and password formatting. (too short/long or containing spaces)
	@Test
	public final void testCreatingInvalidUsernameTooShort() {
		assertEquals("Creating invalid account(username too short)",ManageAccount.createAccValidator("us", "password"),null);
	}
	
	@Test
	public final void testCreatingInvalidUsernameTooLong() {
		assertEquals("Creating invalid account(username too long)",ManageAccount.createAccValidator("1234567890123456", "password"),null);
	}
	
	@Test
	public final void testCreatingInvalidPasswordTooShort() {
		assertEquals("Creating invalid password(password too short)",ManageAccount.createAccValidator("user2", "pass"),null);
	}
	
	@Test
	public final void testCreatingInvalidPasswordTooLong() {
		assertEquals("Creating invalid password(password too long)",ManageAccount.createAccValidator("user2", "123456789012345678901"),null);	
	}

	@Test
	public final void testCreatingInvalidUsernameContainsSpaces() {
		assertEquals("Creating invalid username(contains spaces ' ')",ManageAccount.createAccValidator("us er2", "password"),null);
	}
	
	@Test
	public final void testCreatingInvalidPasswordContainsSpaces() {
		assertEquals("Creating invalid password(contains spaces ' ')",ManageAccount.createAccValidator("user2", "pass word"),null);
	}
	
	
	
	//Testing login for valid usernames with correct password
	@Test
	public final void testLoginValidAccount1() {
		ManageAccount.createAccValidator("user10", "password10");
		ManageAccount.logout();
		assertEquals("Correct Username and password",ManageAccount.confirmDetails("user10", "password10"),"user10");
	}
	@Test
	public final void testLoginValidAccount2() {
		ManageAccount.createAccValidator("user20", "password20");
		ManageAccount.logout();
		assertEquals("Correct Username and password",ManageAccount.confirmDetails("user20", "password20"),"user20");
	}
	@Test
	public final void testLoginValidAccount3() {
		ManageAccount.createAccValidator("user30", "password30");
		ManageAccount.logout();
		assertEquals("Correct Username and password",ManageAccount.confirmDetails("user30", "password30"),"user30");
	}
	
	//Testing login for a valid username but incorrect password
	@Test
	public final void testLoginInvalidAccountCorrectUsernameIncorrectPassword1() {
		assertEquals("Correct Username but incorrect password",ManageAccount.confirmDetails("user10", "incorrect"),null);
	}
	@Test
	public final void testLoginInvalidAccountCorrectUsernameIncorrectPassword2() {
		assertEquals("Correct Username but incorrect password",ManageAccount.confirmDetails("user20", "password10"),null);
	}
	@Test
	public final void testLoginInvalidAccountCorrectUsernameIncorrectPassword3() {
		assertEquals("Correct Username but incorrect password",ManageAccount.confirmDetails("user30", "password20"),null);
	}
	
	//Testing login for incorrect username and incorrect password
	@Test
	public final void testLoginInvalidAccountIncorrectUsernameCorrectPassword1() {
		assertEquals("Existing Password but incorrect username",ManageAccount.confirmDetails("fakeuser", "password20"),null);
	}
	@Test
	public final void testLoginInvalidAccountIncorrectUsernameCorrectPassword2() {
		assertEquals("Existing Password but incorrect username",ManageAccount.confirmDetails("user10", "password20"),null);
	}
	@Test
	public final void testLoginInvalidAccountIncorrectUsernameCorrectPassword3() {
		assertEquals("Existing Password but incorrect username",ManageAccount.confirmDetails("user30", "password20"),null);
	}
	
	
	//Testing login for incorrect username and incorrect password
	@Test
	public final void testLoginInvalidAccountIncorrectUsernameIncorrectPassword1() {
		assertEquals("Incorrect Username and password",ManageAccount.confirmDetails("fakeuser", "idkpassword"),null);
	}
	@Test
	public final void testLoginInvalidAccountIncorrectUsernameIncorrectPassword2() {
		assertEquals("Incorrect Username and password",ManageAccount.confirmDetails("fakeuser2", "password200"),null);
	}
	@Test
	public final void testLoginInvalidAccountIncorrectUsernameIncorrectPassword3() {
		assertEquals("Incorrect Username and Password",ManageAccount.confirmDetails("user1000", "pass3000"),null);
	}
	
	
	//Logout function
	@Test
	public final void testLogoutOfLoggedInUser() {
		ManageAccount.confirmDetails("user10", "password10");
		assertEquals("Logging out of logged in user",ManageAccount.logout(),null);
	}
	@Test
	public final void testLogoutOfLoggedOutUser() {
		ManageAccount.confirmDetails("user10", "password10");
		ManageAccount.logout();
		assertEquals("Logging out of logged out user",ManageAccount.logout(),null);
	}

}
